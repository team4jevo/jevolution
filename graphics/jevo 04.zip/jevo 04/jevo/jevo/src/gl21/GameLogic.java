package gl21;

import javafx.geometry.Insets;
import javafx.scene.paint.Color;
import jevo.GraphicsEngine;

/**
 * Created by on 8/24/2016.
 */
public class GameLogic extends jevo.GameLogic {
   // GraphicsEngine ge;

    public GameLogic(GraphicsEngine ge){
        super(ge);
       // this.ge = ge;
    }
    int tmpX = 0;
    GameObject [][] field;

    public void nextTurn (){

        System.out.println ("next turn in game logic ");
        for (int x = 0; x<field.length ; x++){
            for (int y = 0; y< field[x].length; y++){

                if ( field [x][y] == null  ){
                    System.out.println ("found empty cell ");

                    if (Math.random()>0.5){
                        System.out.println ("adding object");
                        field [x][y] = new GameObject("f",x,y);
                        field [x][y].setToken (super.getGe().createToken (field [x][y]));

                        field [x][y].getToken ().setColor(Color.BLACK);
                    }
                }else if ((Math.random()<0.5)) {

                    try {
                        System.out.println("moving token");

                        field[x][y].getToken().moveAnim(1, -1);
                        field[x + 1][y - 1] = field[x][y];
                        field[x][y] = null;

                    } catch (Exception e) {
                        System.out.println("some other time");
                    }


                } else if (Math.random()>0.5){
                    System.out.println("removing token");
                    field [x][y].removeToken();
                    field [x][y] = null;


                }
            }
        }

    }



    public void newGame (){
        System.out.print("new game fdfdfdf");
        int h = 30;
        int w = 30;
        field = new GameObject[w][h];
        // set starting creatures
        for (int x = 0; x<w ; x++){
            for (int y = 0; y< h; y++){
                if (Math.random()<0.5){
                    field [x][y] = new GameObject("t",x,y);
                    field [x][y].setToken (super.getGe().createToken (field [x][y]));

                }
            }
        }


    }
}
