package gl22;

/**
 * Created by  on 8/24/2016.
 */
public class GameObject extends jevo.GameObject {
   public GameObject (String type,int x,int y){
        super(type,x,y);
    }
}
