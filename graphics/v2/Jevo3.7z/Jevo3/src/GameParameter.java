/**
 * Created by LongJohn on 8/19/2016.
 */
public class GameParameter {

    //do not mind this class for now
    public String value;


}
