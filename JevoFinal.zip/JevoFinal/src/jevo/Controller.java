package jevo;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * Created by LongJohn on 8/19/2016.
 */
//when new game logic object is created graphic engine is passed to it in constructor
public class Controller {
    // this class processes user events and calls needed methods of GameLogic


    private int selectedSimulation ;
    private Stage stage;



    @FXML
    private ChoiceBox cbGameLogicSelector;



    @FXML
    private TableView<GameParameter> tblGoProperties;

    @FXML
    private TableColumn<GameParameter,String> colGoValue ;

    @FXML
    private TableColumn<GameParameter,String> colGoParameter ;

    GraphicsEngine ge = new GraphicsEngine(this);
    GameLogic gl = new jevosim.GameLogic(ge);


    Timeline timeline = new Timeline (new KeyFrame(
            Duration.millis(20),
            ae -> {
             //   System.out.println ("tick");
                try {
                    gl.nextTurn();
                }catch (Exception e){
                    System.err.print(e);
                }
            }
    ));


    @FXML
    private Pane paneField;


    @FXML
    private Button playBtn;

    @FXML
    protected TextField tfTurns ;

    @FXML
    protected TextField tfSpeed ;


    @FXML
    protected Button btnNewGame;
    private boolean simulationInProgress = false;


    private void prepareForSimulation () {
        simulationInProgress = false;
        stopTimeline ();
        ge.reset();
        btnNewGame.setText("Start Simulation");
        tmpGoForTable = null;
        tmpGlForTable = null;
        setGl();
        displayGlStatsInTable(gl);

    }




    @FXML
    protected void handleNewGame (ActionEvent event) throws Exception {


        if (simulationInProgress){ // simulatiion is running. stop it and prepare for the new one
            prepareForSimulation ();

        }else { // simulation starts
            simulationInProgress = true;
            btnNewGame.setText("Set New Simulation");
            ge.setTileSize(gl.getTokenSize());
          //  ge.reset();
            gl.newGame();
        }

    }
    private void stopTimeline (){
        timeline.stop();
        paused = true;
        playBtn.setText("> ");
    }



    @FXML
    protected void handleNextTurn (ActionEvent event) throws Exception {
        if (simulationInProgress) {
            try {
                int turns = 0;
                try {
                    turns = Integer.valueOf(tfTurns.getText());
                } catch (Exception e) {
                    turns = 1;
                    tfTurns.setText("1");
                }
                for (int i = 0; i < turns; i++) {
                    gl.nextTurn();
                }
            } catch (Exception e) {
            }
        }
    }





    @FXML
    protected void handleSave (ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Simulation");
        File file = fileChooser.showOpenDialog(stage);


        try {
            gl.saveFile(file);
        } catch (Exception e) {
            System.err.print (e);
        }
    }


    @FXML
    protected void handleLoad (ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load Simulation");
        File file = fileChooser.showOpenDialog(stage);
        try {
            //prepareForSimulation ();
            ge.setTileSize(gl.getTokenSize());
            gl.loadFile(file);
        } catch (Exception e) {
            System.err.print (e);
        }
    }


    private boolean paused = true;
    private Double turnRate = 0.05;



    @FXML
    protected void handlePlay (ActionEvent event) throws Exception {
        try {
            if (paused && simulationInProgress) {
                paused = false;
                playBtn.setText("|| ");
                timeline.setCycleCount(Animation.INDEFINITE);
                timeline.setRate(turnRate);
                timeline.play();


            } else {

                stopTimeline ();
            }
        }catch (Exception e ){

        }

    }// end handle play

    @FXML
    protected void handleSpeedChange (ActionEvent event){

        try {
            turnRate = Double.valueOf(tfSpeed.getText())*0.05;
            if (turnRate > 1.5 ){
                turnRate = 1.5;
                tfSpeed.setText("30.0");
            }

        } catch (Exception e) {
            System.out.println ("exception in speedchange");
            turnRate = 0.05;
            tfSpeed.setText("1.0");
        }
        timeline.setRate(turnRate);

    }

///////////////////////////////////////////////////////////////////////////////////////////////////// tabele

    private int tableObject; // 0 go ; 1 gl

    private GameObject tmpGoForTable;
    private GameLogic tmpGlForTable;


    public void displayGoStatsInTable (GameObject go){

        tmpGoForTable = go;
        tableObject = 0;
        processTableGo();
    }

    public void displayGlStatsInTable (GameLogic gl){
        tmpGlForTable = gl ;
        tableObject = 1;
        processTableGl();
    }

    public void processTableGo (){
        tableObject = 0;
        colGoValue.setCellFactory(TextFieldTableCell.forTableColumn());
        tblGoProperties.setItems (getParam(tmpGoForTable.getRenderedStats()));
    }

    public void processTableGl (){
        tableObject = 1;
        colGoValue.setCellFactory(TextFieldTableCell.forTableColumn());
        tblGoProperties.setItems (getParam(tmpGlForTable.getRenderedStats()));
    }




    public ObservableList<GameParameter> getParam (Hashtable<String,String> ht){
        ObservableList<GameParameter> gamePros = FXCollections.observableArrayList();

        Enumeration<String> key = ht.keys();
        while (key.hasMoreElements()) {
            String k = key.nextElement();
            String v = ht.get(k);
            gamePros.add(new GameParameter (k, v));
        }
        return gamePros;
    }





    private void setUpTable () {
        tblGoProperties.setEditable(true);
        tblGoProperties.setEditable(true);
        colGoParameter.setCellValueFactory(new PropertyValueFactory<>("property"));

        colGoValue.setCellValueFactory(new PropertyValueFactory<>("value"));
        colGoValue.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<GameParameter, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<GameParameter, String> e) {
                if (tableObject==0) {

                    if (!tmpGoForTable.modifyStat(colGoParameter.getCellData(e.getTablePosition().getRow()), e.getNewValue())) {
                        processTableGo();
                    }

                }else if (tableObject==1 ){
                    try {
                        if (!tmpGlForTable.modifyStat(colGoParameter.getCellData(e.getTablePosition().getRow()), e.getNewValue())) {
                            processTableGo();
                        }
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
    }





///////////////////////////////////////////////////////////////////////////////////////////////////// tabele

    private void setGl () {
        switch (selectedSimulation) {
            case 0:
                gl = new jevosim.GameLogic(ge);
                break;
            case 1:
                gl = new gl31.GameLogic(ge);
                break;
            default:
                gl = new jevosim.GameLogic(ge);
                break;
        }
    }



    @FXML
    public void initialize(){
        ge.setPaneField(paneField);
      //  cbGameLogicSelector.setText("First");
        selectedSimulation=0;





        cbGameLogicSelector.setItems(FXCollections.observableArrayList(
                "jevosim", "jevogame") // add your stuff here
        );


        cbGameLogicSelector.getSelectionModel().selectedIndexProperty().addListener (new
            ChangeListener<Number>() {
            public void changed (ObservableValue ov, Number value, Number new_value){

                selectedSimulation = new_value.intValue();
                prepareForSimulation();

            }
        });

        setGl ();
        prepareForSimulation();


        tmpGlForTable = gl;
        setUpTable ();
        processTableGl();


    }//ini
}//controller

