package jevo;

import javafx.geometry.Insets;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;

/**
 * Created by LongJohn on 8/19/2016.
 */
public class Token extends StackPane {
    // visual representation of game object

    private int x, y ;
    private Text tf;


    public GraphicsEngine getGe() {
        return ge;
    }

    public void setColor (Color newColor){
        sh.setFill(newColor);
    }



    public void setText (String newText){
        tf.setText(newText);
    }

    private GraphicsEngine ge;
    private GameObject go;

    private Shape sh;
    int size;

    public Token (GameObject go,  int size, GraphicsEngine ge){
        setPadding(new Insets(1,1,1,1));
        this.ge = ge;//GraphicalEngine
        this.go = go;//GameObject
        go.setToken(this);
        this.x = go.getLogicX()*size;
        this.y = go.getLogicY()*size;
        this.size = size;
        sh = new Rectangle(size-2, size-2);

        tf = new Text (go.getGoType());

        setTranslateX (x);
        setTranslateY (y);
        sh.setFill(Color.rgb(80,80,80));
        getChildren().add(sh);
        setOnMouseClicked(e -> {

            ge.getController().displayGoStatsInTable(go);
        });
    }


    public void moveTo (int newX, int newY) { // moves to new coordinates
        x = newX*size;
        y = newY*size;
        setTranslateX (x);
        setTranslateY (y);
    }

    public void move (int xPath, int yPath){
        x += xPath*size;
        y += yPath*size;
        setTranslateX (x);
        setTranslateY (y);
    }


    public void die (){
        ge.getTokens().remove(this);
        ((Pane) Token.this.getParent()).getChildren().remove (Token.this);
    }

}
